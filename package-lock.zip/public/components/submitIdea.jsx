import { useState } from "react";
import { supabase } from "../utils/supabaseClient";

export default function SubmitIdea({ user }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [visibility, setVisibility] = useState("public");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { error } = await supabase.from("ideas").insert([
      {
        title,
        description,
        user_id: user.id,
        visibility,
      },
    ]);
    if (error) alert("Error posting idea");
    else alert("Idea posted!");
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Post Your Idea</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          className="w-full p-2 border"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <textarea
          className="w-full p-2 border"
          placeholder="Describe your idea..."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <select
          value={visibility}
          onChange={(e) => setVisibility(e.target.value)}
          className="w-full p-2 border"
        >
          <option value="public">Public</option>
          <option value="private">Private</option>
        </select>
        <button className="bg-violet-600 text-white px-4 py-2 rounded">
          Post Idea
        </button>
      </form>
    </div>
  );
}
