// src/components/MissionSection.jsx
import React from "react";
import { motion } from "framer-motion";

export default function MissionSection() {
  return (
    <motion.section
      className="bg-gradient-to-r from-purple-800 via-indigo-900 to-purple-800 rounded-3xl border-4 border-fuchsia-500 shadow-2xl my-20 px-8 py-12 text-white"
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <motion.h2
        className="text-4xl md:text-5xl font-extrabold text-pink-300 mb-6 text-center"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.7 }}
      >
        Our Mission
      </motion.h2>

      <motion.p
        className="text-lg md:text-xl text-indigo-100 max-w-3xl mx-auto text-center leading-relaxed"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.8 }}
      >
       𝐀𝐭 𝐒𝐰𝐚𝐩𝐒𝐦𝐚𝐫𝐭, 𝐰𝐞 𝐛𝐞𝐥𝐢𝐞𝐯𝐞 𝐢𝐧 𝐭𝐡𝐞 𝐩𝐨𝐰𝐞𝐫 𝐨𝐟 𝐬𝐭𝐮𝐝𝐞𝐧𝐭𝐬 𝐡𝐞𝐥𝐩𝐢𝐧𝐠 𝐬𝐭𝐮𝐝𝐞𝐧𝐭𝐬.


𝐎𝐮𝐫 𝐦𝐢𝐬𝐬𝐢𝐨𝐧 𝐢𝐬 𝐭𝐨 𝐜𝐫𝐞𝐚𝐭𝐞 𝐚 𝐭𝐡𝐫𝐢𝐯𝐢𝐧𝐠 𝐜𝐨𝐦𝐦𝐮𝐧𝐢𝐭𝐲 𝐰𝐡𝐞𝐫𝐞 𝐢𝐝𝐞𝐚𝐬 𝐬𝐩𝐚𝐫𝐤 𝐢𝐧𝐧𝐨𝐯𝐚𝐭𝐢𝐨𝐧, 𝐰𝐡𝐞𝐫𝐞 𝐤𝐧𝐨𝐰𝐥𝐞𝐝𝐠𝐞 𝐢𝐬 𝐬𝐡𝐚𝐫𝐞𝐝 𝐟𝐫𝐞𝐞𝐥𝐲, 𝐚𝐧𝐝 𝐰𝐡𝐞𝐫𝐞 𝐜𝐨𝐥𝐥𝐚𝐛𝐨𝐫𝐚𝐭𝐢𝐨𝐧 𝐛𝐮𝐢𝐥𝐝𝐬 𝐜𝐨𝐧𝐟𝐢𝐝𝐞𝐧𝐜𝐞. 𝐖𝐞’𝐫𝐞 𝐡𝐞𝐫𝐞 𝐭𝐨 𝐦𝐚𝐤𝐞 𝐞𝐯𝐞𝐫𝐲 𝐬𝐭𝐮𝐝𝐞𝐧𝐭 𝐟𝐞𝐞𝐥 𝐬𝐞𝐞𝐧, 𝐬𝐮𝐩𝐩𝐨𝐫𝐭𝐞𝐝, 𝐚𝐧𝐝 𝐢𝐧𝐬𝐩𝐢𝐫𝐞𝐝 — 𝐭𝐮𝐫𝐧𝐢𝐧𝐠 𝐢𝐧𝐝𝐢𝐯𝐢𝐝𝐮𝐚𝐥 𝐞𝐟𝐟𝐨𝐫𝐭𝐬 𝐢𝐧𝐭𝐨 𝐜𝐨𝐥𝐥𝐞𝐜𝐭𝐢𝐯𝐞 𝐠𝐫𝐨𝐰𝐭𝐡.


      </motion.p>
    </motion.section>
  );
}
